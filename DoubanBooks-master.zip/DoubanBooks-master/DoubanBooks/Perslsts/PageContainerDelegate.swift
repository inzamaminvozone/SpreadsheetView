//
//  PageContainerDelegate.swift
//  DoubanBooks
//
//  Created by 2017yd on 2019/11/12.
//  Copyright © 2019年 2017yd. All rights reserved.
//

import Foundation
protocol PageContainerDelegate {
    func switchTabButton(to index:Int)
}
