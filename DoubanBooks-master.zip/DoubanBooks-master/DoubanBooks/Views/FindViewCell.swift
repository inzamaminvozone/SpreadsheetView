//
//  FindViewCell.swift
//  DoubanBooks
//
//  Created by 2017yd on 2019/10/31.
//  Copyright © 2019年 2017yd. All rights reserved.
//

import UIKit

class FindViewCell: UICollectionViewCell {
    @IBOutlet weak var imgCover: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblUserName: UILabel!
    @IBOutlet weak var imgStar: UIImageView!
    
}
