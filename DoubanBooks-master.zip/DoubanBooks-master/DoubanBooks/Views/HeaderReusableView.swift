//
//  HeaderReusableView.swift
//  DoubanBooks
//
//  Created by 2017yd on 2019/10/31.
//  Copyright © 2019年 2017yd. All rights reserved.
//

import UIKit

class HeaderReusableView: UICollectionReusableView {
    @IBOutlet weak var seaechBar: UISearchBar!
    
}
